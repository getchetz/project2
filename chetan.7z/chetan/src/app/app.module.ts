import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Route, RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BookComponent } from './book/book.component';
import { HttpClientModule} from '@angular/common/http';
import { BookformComponent } from './bookform/bookform.component';

const routes : Route [] =[

 
  //for book access
{
  path : 'book',
  component : BookComponent
},

//for bookform access
{
  path : 'bookform',
  component : BookformComponent
}];

@NgModule({
  declarations: [
    AppComponent,
    BookComponent,
    BookformComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,

      //module for httpclient 
      HttpClientModule,
      //passing the arary of routes created above to rootermodule using forRoot
      RouterModule.forRoot(routes)

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
