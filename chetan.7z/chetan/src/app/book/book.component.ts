import { Component, OnInit } from '@angular/core';
import { BookserviceService } from '../bookservice.service';
import { Ibook } from './book';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  
  //reference for Ibook(array)
  books:Ibook[];

  constructor(private service:BookserviceService) { }

  ngOnInit() {
    this.service.getBooks().subscribe(data=>this.books=data);
  }

}
