import { Title } from '@angular/platform-browser';

export interface Ibook{
    id: number,
    title: string,
    year : number,
    author: string 
}
