import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Ibook } from './book/book';

@Injectable({
  providedIn: 'root'
})
export class BookserviceService {

  url:string="assets/booklist.json";

  constructor(private http:HttpClient) {}
  getBooks():Observable<Ibook[]>
  {
    return this.http.get<Ibook[]>(this.url);
  }
}
