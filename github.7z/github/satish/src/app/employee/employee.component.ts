import { Component, OnInit } from '@angular/core';
import { Iemployee } from './employee';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  employee : Iemployee []=
  [
  {
    eid : 1001,
    ename : "Sathe",
    esalery : 20000
  },
  {
    eid : 1002,
    ename : "Yeskee",
    esalery : 30000
  }
];
  constructor() { }

  ngOnInit()
  {
  }
  delete (emp : Iemployee )
  {
   let arr= this.employee.filter(p=>p.eid!=emp.eid)
   this.employee=arr;
  }
}
