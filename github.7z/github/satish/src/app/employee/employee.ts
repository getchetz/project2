export interface Iemployee
{
    eid : number;
    ename : string;
    esalery : number;
}