import { Component, OnInit } from '@angular/core';
import{ActivatedRoute} from '@angular/router'
import { from } from 'rxjs';

@Component({
  selector: 'app-employeedetails',
  templateUrl: './employeedetails.component.html',
  styleUrls: ['./employeedetails.component.css']
})
export class EmployeedetailsComponent implements OnInit {
  empid;

  constructor(private route:ActivatedRoute) { }

  ngOnInit() {
    let id=this.route.snapshot.params['id'];
    this.empid=id;
  }

}
