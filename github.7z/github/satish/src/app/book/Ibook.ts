export interface Ibook
{    
        id:number;
        title: string;
        year : number;
        author : string ;  
}