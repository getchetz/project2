import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http'
import { Observable } from '../../node_modules/rxjs';
import { Ibook } from './book/Ibook';

@Injectable(
    {
        providedIn : 'root'
    }
)
export class BookService{
    url : string = "assets/booklist.json"
    constructor (private http : HttpClient)
    {
    }
        getBooks() : Observable<Ibook []>
        {
            return this.http.get<Ibook []>(this.url);            
        }
    }