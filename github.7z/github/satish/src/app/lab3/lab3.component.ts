import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '../../../node_modules/@angular/forms';
import { Iproduct } from './Iproduct';

@Component({
  selector: 'app-lab3',
  templateUrl: './lab3.component.html',
  styleUrls: ['./lab3.component.css']
})
export class Lab3Component implements OnInit {
  useForm : FormGroup ;
  product : Iproduct[];
  constructor() { }
we
  ngOnInit() 
  {
    this.useForm= new FormGroup
    ({
      pid : new FormControl(null,[Validators.required, Validators.pattern("^[0-9]{1,3}")]),
      pname : new FormControl(null,[Validators.required,Validators.minLength(6)]),
      pcost : new FormControl(),
      ponline : new FormControl(), 
      category : new FormControl(),
      available : new FormControl()         
    });
  }
  onSubmit(obj : any)
  {    
   // this.product.push({pid:obj.pid, pname:obj.pname, pcost:obj.pcost})   
    console.log(obj);
    //console.warn(obj.value);
  }
}