export interface Iproduct
{    
        pid:number;
        pname: string;
        pcost : number;   
           
}