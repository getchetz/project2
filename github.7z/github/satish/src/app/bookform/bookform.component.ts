import { Component, OnInit } from '@angular/core';
import { BookService } from '../bookservice';
import { Ibook } from '../book/Ibook';
import { FormGroup, FormControl, Validators } from '../../../node_modules/@angular/forms';

@Component({
  selector: 'app-bookform',
  templateUrl: './bookform.component.html',
  styleUrls: ['./bookform.component.css']
})
export class BookformComponent implements OnInit {
userForm : FormGroup ;
books:Ibook[];

  constructor(private service:BookService) { }

  ngOnInit() 
  {
      this.userForm= new FormGroup
      (
        {
      id : new FormControl(null,[Validators.required, Validators.pattern("^[0-9]{1,2}")]),
      title : new FormControl(null,[Validators.required,Validators.minLength(6)]),
      year : new FormControl(2019,[Validators.required,Validators.pattern("^[0-9]{4}")]),
      author : new FormControl(null,[Validators.pattern("^[A-Z]{1}[a-z]{2,8}$")])
        }
      );
    this.service.getBooks().subscribe(data=>this.books=data);
  }
  onSubmit(b : any)
  {
    let arr=this.books.filter(s=>s.id==b.id);
    if(arr.length > 0)
    {
      alert("ID Already Exists")
    }
    else
  {
    this.books.push({id:b.id, title:b.title, year:b.year,author:b.author})  
  }
  }
  update(b :any)
  {
    
  }
}