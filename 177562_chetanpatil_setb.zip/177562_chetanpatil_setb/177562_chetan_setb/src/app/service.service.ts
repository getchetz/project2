import { Injectable } from '@angular/core';
import {HttpClientModule,HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {Igame} from './game/game';
@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  url:string="assets/GameList.json";
  constructor(private http:HttpClient) { }
  getGames():Observable<Igame []>
{

 return this.http.get<Igame []>(this.url);
}
showDate()
  {
    let date= new Date();
    return date;
  }
}
